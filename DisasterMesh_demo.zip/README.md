# DisasterMesh — 90-minute hackathon demo

Open `index.html` in a browser. It is a self-contained software demo with:
- Citizen SOS
- automatic emergency type/severity/location classification
- duplicate report clustering by location
- dispatcher triage
- rescue-unit dispatch and status tracking
- persistent browser storage
- live-style incident map

Demo text:
"Flood water has entered my house near Velachery and two people are trapped."

Expected classification: FLOOD / CRITICAL / Velachery.
